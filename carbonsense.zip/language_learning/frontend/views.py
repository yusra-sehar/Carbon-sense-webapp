from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import stripe
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import UserProfile, PaymentHistory
from django.utils import timezone
from datetime import timedelta

# Initialize Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

# ============ AUTH VIEWS ============

def index(request):
    """Login page"""
    if request.user.is_authenticated:
        return redirect('success')
    return render(request, 'index.html')

def login_view(request):
    """Handle login"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('success')
        else:
            messages.error(request, 'Invalid username or password')
    
    return redirect('index')

def logout_view(request):
    """Handle logout"""
    logout(request)
    return redirect('index')

def register(request):
    """Handle registration"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('success')
    else:
        form = UserCreationForm()
    
    return render(request, 'index.html', {'form': form})

# ============ PAGE VIEWS ============

@login_required
def success(request):
    """Home page after login"""
    return render(request, 'success.html')

@login_required
def calculator(request):
    """Carbon calculator page"""
    return render(request, 'calculator.html')

@login_required
def premium(request):
    """Premium features page"""
    return render(request, 'premium.html')

@login_required
def dashboard(request):
    """User dashboard"""
    return render(request, 'dashboard.html')

@login_required
def reports(request):
    """Reports page"""
    return render(request, 'reports.html')

# ============ PAYMENT VIEWS ============

@login_required
def payment_page(request):
    """Show payment page"""
    return render(request, 'payment_page.html')

@login_required
def create_checkout_session(request):
    """Create Stripe checkout session"""
    try:
        # Get or create user profile
        profile, created = UserProfile.objects.get_or_create(user=request.user)
        
        # Create checkout session
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': 'CarbonSense Premium',
                        'description': 'Monthly Subscription',
                    },
                    'unit_amount': 499,  # $4.99 in cents
                },
                'quantity': 1,
            }],
            mode='subscription',
            success_url=request.build_absolute_uri('/payment/success/') + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.build_absolute_uri('/payment/cancel/'),
            metadata={
                'user_id': request.user.id,
            }
        )
        
        return redirect(checkout_session.url)
        
    except Exception as e:
        messages.error(request, f"Error: {str(e)}")
        return redirect('payment_page')

@login_required
def payment_success(request):
    """Handle successful payment"""
    session_id = request.GET.get('session_id')
    
    if session_id:
        try:
            # Retrieve session from Stripe
            session = stripe.checkout.Session.retrieve(session_id)
            
            # Update user profile
            profile, created = UserProfile.objects.get_or_create(user=request.user)
            profile.is_premium = True
            profile.premium_start_date = timezone.now()
            profile.premium_end_date = timezone.now() + timedelta(days=30)  # 1 month
            profile.stripe_customer_id = session.customer
            profile.save()
            
            # Save payment record
            PaymentHistory.objects.create(
                user=request.user,
                amount=4.99,
                stripe_payment_intent=session.payment_intent,
                status='completed'
            )
            
            messages.success(request, "🎉 Premium activated successfully!")
            
        except Exception as e:
            messages.error(request, f"Error processing payment: {str(e)}")
    
    return render(request, 'payment_success.html')

@login_required
def payment_cancel(request):
    """Handle cancelled payment"""
    messages.info(request, "Payment was cancelled.")
    return render(request, 'payment_cancel.html')

@login_required
def activate_free_trial(request):
    """Activate free trial"""
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    profile.is_premium = True
    profile.premium_start_date = timezone.now()
    profile.premium_end_date = timezone.now() + timedelta(days=7)  # 7 days trial
    profile.save()
    
    messages.success(request, "🎉 7-day free trial activated!")
    return redirect('dashboard')

# Webhook (optional for now)
@csrf_exempt
def stripe_webhook(request):
    """Handle Stripe webhooks"""
    return JsonResponse({'status': 'success'})