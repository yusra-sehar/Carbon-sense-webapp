from django.contrib import admin
from .models import UserProfile, PaymentHistory

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_premium', 'premium_start_date', 'premium_end_date')
    list_filter = ('is_premium',)
    search_fields = ('user__username', 'user__email')

@admin.register(PaymentHistory)
class PaymentHistoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('user__username', 'stripe_payment_intent')
    readonly_fields = ('created_at',)