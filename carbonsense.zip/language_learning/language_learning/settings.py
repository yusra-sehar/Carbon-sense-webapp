import os
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
SECRET_KEY = 'django-insecure-m3ez078_exlw-##(lbj&&&g97!u$#d#il=+)0b_i8=q^mebm@+'
DEBUG = True
ALLOWED_HOSTS = []

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'frontend'  # Your app
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'language_learning.urls'

# Template Configuration
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'frontend/templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'language_learning.wsgi.application'

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# 🔥🔥🔥 FIXED: STATIC FILES CONFIGURATION (Only one definition!)
STATIC_URL = '/static/'
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'frontend/static'),  # Your app static files
    # os.path.join(BASE_DIR, 'static'),  # If you have global static folder
]

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Stripe Configuration - ADD THESE LINES AT BOTTOM
STRIPE_PUBLISHABLE_KEY = 'pk_test_51SqSzWQ1PeOuYsmXwNvYS5IbaVnwAwlPt4kDsRmFrFL9RYLJ0AE06IRj7gk1miFiFIHNY7HD343kuqAYd6uM8oivj8M0xbbxiLa4'
STRIPE_SECRET_KEY = 'sk_test_51SqSzWQ1PeOuYsmX9KQJM58NSENIZZOmRGUr4qFySZ6z4LkRufK4tyZrwC1jgDgEw64zhCo3vtQBMTmJeeyMP0RR89tIbH'


# ============ AUTHENTICATION SETTINGS ============
LOGIN_URL = '/login/'  # Yeh sahi hai, aapke URLs mein 'login/' hai
LOGIN_REDIRECT_URL = '/success/'  # Login ke baad success page par jayega
LOGOUT_REDIRECT_URL = '/'  # Logout ke baad index page par jayega

